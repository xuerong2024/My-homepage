# 欢迎来到我的小站 👋

这是一个用 **Python 的 MkDocs + Material 主题** 生成的静态网站。
你可以用 Markdown 写文章，然后一键生成网页。

- 📝 文章请放在 `docs/` 目录
- 🚀 本地预览：`mkdocs serve`
- 🏗️ 构建静态站点：`mkdocs build`

想换主题或外观？编辑根目录下的 `mkdocs.yml`。

> 下面是我的最新文章：