# 第一篇文章：Hello, World!

恭喜你，用 Markdown 成功发布了第一篇文章。

```python
def hello():
    print("Hello, world!")
```